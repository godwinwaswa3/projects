// Wait until the browser is ready to render the game.
// This avoids rendering glitches on initial load.
window.requestAnimationFrame(function () {

  /*
   * The feature API proxy.
   *
   * Browser:
   *     http://localhost:3001
   *
   * Proxy:
   *     http://localhost:3000/api/features
   */
  window.PEANUT_CREDITS_PROXY_URL =
    "http://localhost:3001";


  /*
   * Create the normal 2048 game.
   *
   * IMPORTANT:
   * Do not move FeatureManager inside GameManager.
   * This preserves the existing architecture.
   */
  var game = new GameManager(
    4,
    KeyboardInputManager,
    HTMLActuator,
    LocalStorageManager,
    CreditsManager
  );


  /*
   * Make the game globally available.
   *
   * FeatureManager uses this reference to obtain:
   *
   * - player ID
   * - round timer
   * - round end time
   * - game state
   */
  window.drissnowGame = game;


  /*
   * Start the compound economy feature.
   *
   * FeatureManager waits for CreditsManager to obtain
   * the player ID before creating the database session.
   */
  if (typeof FeatureManager !== "undefined") {

    window.drissnowFeatures =
      new FeatureManager(game);

  }


  /*
   * ==============================
   * REDEEM CODE
   * ==============================
   */

  var redeemButton =
    document.querySelector(".redeem-button");

  var redeemInput =
    document.querySelector(".redeem-input");

  var redeemMessage =
    document.querySelector(".redeem-message");


  if (redeemButton) {

    redeemButton.addEventListener(
      "click",
      async function () {

        try {

          var code =
            redeemInput.value.trim();

          if (!code) {

            redeemMessage.textContent =
              "Enter a peanut code.";

            redeemMessage.className =
              "redeem-message error";

            return;
          }


          var result =
            await game.creditsManager.redeemCode(
              code
            );


          redeemMessage.textContent =
            result.message;

          redeemMessage.className =
            "redeem-message " +
            (
              result.success
                ? "success"
                : "error"
            );


          redeemInput.value = "";


          /*
           * Refresh displayed credits.
           */
          var credits =
            await game.creditsManager.getCredits();

          game.actuator.updateCredits(
            credits
          );


          /*
           * If redemption succeeded,
           * restart/setup the game exactly as
           * the original application did.
           */
          if (result.success) {

            game.setup();

          }

        } catch (err) {

          console.error(
            "Redeem error:",
            err
          );

          redeemMessage.textContent =
            "Something went wrong. Please try again.";

          redeemMessage.className =
            "redeem-message error";

        }

      }
    );

  }


  /*
   * ==============================
   * KEEP BOARD SQUARE
   * ==============================
   *
   * Safety fallback for browsers that
   * don't support CSS aspect-ratio.
   */

  var gameContainer =
    document.querySelector(
      ".game-container"
    );


  function squareUpBoard() {

    if (!gameContainer) {
      return;
    }

    var width =
      gameContainer.offsetWidth;

    if (width > 0) {

      gameContainer.style.height =
        width + "px";

    }

  }


  squareUpBoard();


  window.addEventListener(
    "resize",
    squareUpBoard
  );


  window.addEventListener(
    "orientationchange",
    squareUpBoard
  );

});