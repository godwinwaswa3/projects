function HTMLActuator() {
  this.tileContainer    = document.querySelector(".tile-container");
  this.scoreContainer   = document.querySelector(".score-container");
  this.bestContainer    = document.querySelector(".best-container");
  this.creditsContainer = document.querySelector(".credits-container");
  this.timerContainer   = document.querySelector(".timer-container");
  this.timerInput       = document.querySelector(".timer-input");
  this.gameOverBanner   = document.querySelector(".game-over-banner");
  this.gameOverText     = document.querySelector(".game-over-text");
  this.noCreditsOverlay = document.querySelector(".no-credits-overlay");
  this.prizeToast       = document.querySelector(".prize-toast");
  this.prizeToastText   = document.querySelector(".prize-toast-text");

  this.score      = 0;
  this.gridSize   = 4;
  this.toastTimer = null;
}

HTMLActuator.prototype.actuate = function (grid, metadata) {
  var self = this;
  this.gridSize = grid.size;

  window.requestAnimationFrame(function () {
    self.clearContainer(self.tileContainer);

    grid.cells.forEach(function (column) {
      column.forEach(function (cell) {
        if (cell) {
          self.addTile(cell);
        }
      });
    });

    self.updateScore(metadata.score);
    self.updateBestScore(metadata.bestScore);

    if (metadata.terminated) {
      self.showGameOver();
    } else {
      self.hideGameOver();
    }
  });
};

HTMLActuator.prototype.clearContainer = function (container) {
  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }
};

HTMLActuator.prototype.setTilePosition = function (element, position) {
  var size  = this.gridSize || 4;
  var inset = 1.5;
  var cell  = 100 / size;

  element.style.left   = (position.x * cell + inset) + "%";
  element.style.top    = (position.y * cell + inset) + "%";
  element.style.width  = (cell - inset * 2) + "%";
  element.style.height = (cell - inset * 2) + "%";
};

HTMLActuator.prototype.addTile = function (tile) {
  var self = this;

  var wrapper = document.createElement("div");
  var inner   = document.createElement("div");
  var position = tile.previousPosition || { x: tile.x, y: tile.y };

  var classes = ["tile", "tile-" + tile.value];
  if (tile.value > 2048) classes.push("tile-super");

  this.applyClasses(wrapper, classes);
  this.setTilePosition(wrapper, position);

  inner.classList.add("tile-inner");
  inner.textContent = tile.value;

  if (tile.previousPosition) {
    window.requestAnimationFrame(function () {
      self.setTilePosition(wrapper, { x: tile.x, y: tile.y });
    });
  } else if (tile.mergedFrom) {
    classes.push("tile-merged");
    this.applyClasses(wrapper, classes);

    tile.mergedFrom.forEach(function (merged) {
      self.addTile(merged);
    });
  } else {
    classes.push("tile-new");
    this.applyClasses(wrapper, classes);
  }

  wrapper.appendChild(inner);
  this.tileContainer.appendChild(wrapper);
};

HTMLActuator.prototype.applyClasses = function (element, classes) {
  element.setAttribute("class", classes.join(" "));
};

HTMLActuator.prototype.updateScore = function (score) {
  this.clearContainer(this.scoreContainer);

  var difference = score - this.score;
  this.score = score;
  this.scoreContainer.textContent = this.score;

  if (difference > 0) {
    var addition = document.createElement("div");
    addition.classList.add("score-addition");
    addition.textContent = "+" + difference;
    this.scoreContainer.appendChild(addition);
  }
};

HTMLActuator.prototype.updateBestScore = function (bestScore) {
  this.bestContainer.textContent = bestScore;
};

HTMLActuator.prototype.updateCredits = function (credits) {
  this.creditsContainer.textContent = credits;
};

HTMLActuator.prototype.updateTimer = function (seconds) {
  var clamped = Math.max(0, seconds);
  var mins = Math.floor(clamped / 60);
  var secs = clamped % 60;
  this.timerContainer.textContent = mins + ":" + (secs < 10 ? "0" : "") + secs;
  this.timerContainer.classList.toggle("timer-low", clamped <= 10);
};

// Reads the player's chosen round length from the number input.
// Returns NaN if empty/invalid -- caller applies the default + clamp.
HTMLActuator.prototype.getRoundDurationInput = function () {
  return parseInt(this.timerInput.value, 10);
};

// Locked while a round is in progress so the duration can't be
// changed mid-round; unlocked once the round ends or before it starts.
HTMLActuator.prototype.setTimerInputEnabled = function (enabled) {
  this.timerInput.disabled = !enabled;
};

HTMLActuator.prototype.noCredits = function () {
  this.noCreditsOverlay.classList.add("no-credits-visible");
};

HTMLActuator.prototype.hideNoCredits = function () {
  this.noCreditsOverlay.classList.remove("no-credits-visible");
};

HTMLActuator.prototype.setGameOverReason = function (reason) {
  this.gameOverText.textContent = reason + " Tap RESTART above to play again.";
};

HTMLActuator.prototype.showGameOver = function () {
  this.gameOverBanner.classList.add("game-over-visible");
};

HTMLActuator.prototype.hideGameOver = function () {
  this.gameOverBanner.classList.remove("game-over-visible");
};

// Non-blocking milestone/bonus toast. `value` may be null for a
// generic bonus (e.g. the end-of-round score bonus) rather than a
// specific tile milestone.
HTMLActuator.prototype.showPrizeToast = function (value, bonus, prefix) {
  var self = this;
  prefix = prefix || "";

  var label = value
    ? value + " tile reached! "
    : "";

  this.prizeToastText.textContent =
    prefix + label + "+" + bonus + " credit" + (bonus === 1 ? "" : "s") + " added.";

  this.prizeToast.classList.add("prize-toast-visible");

  if (this.toastTimer) clearTimeout(this.toastTimer);
  this.toastTimer = setTimeout(function () {
    self.prizeToast.classList.remove("prize-toast-visible");
  }, 2600);
};
