Money Game 2048



    <p class="game-explanation">
      <strong class="important">How to play:</strong> Use your <strong>arrow keys</strong> to move the tiles. When two tiles with the same number touch, they <strong>merge into one!</strong>
    </p>
    <hr>
    <p>
    <strong class="important">Note:</strong> This is the DrissNow implementation of the Game 2048. Recreated by Godwin Waswa, a medical student at Moi University, Eldoret, Kenya.
    </p>